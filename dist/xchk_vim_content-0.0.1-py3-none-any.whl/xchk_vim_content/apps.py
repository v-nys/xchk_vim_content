from django.apps import AppConfig


class VimcontentConfig(AppConfig):
    name = 'xchk_vim_content'
